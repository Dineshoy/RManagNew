package com.cg.rms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.bean.CandidateWorkHistory;
import com.cg.rms.exception.RecruitmentManagementException;

public class IRmsDaoImpl implements IRmsDao {
	
	private Connection conn;
	
	

	private String generateWorkId() throws RecruitmentManagementException{
		
		conn = DBUtil.getConnection();
		String sql = "SELECT seq_work_id.NEXTVAL FROM DUAL";
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getString(1);
		} catch (SQLException e) {
			throw new RecruitmentManagementException("problem in generating course Id"+e.getMessage());
		}
	}
	
	
	@Override
	public String insertCandidateWorkHistory(CandidateWorkHistory chistory) throws RecruitmentManagementException {
		
		
		chistory.setWork_id(generateWorkId());
		String sql ="INSERT INTO candidate_work_history VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
		conn = DBUtil.getConnection();
		try {
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1, chistory.getWork_id());
		pst.setString(2, chistory.getCandidate_id());
		pst.setString(3, chistory.getWhich_employer());
		pst.setString(4, chistory.getContact_person());
		pst.setString(5, chistory.getPosition_held());
		pst.setString(6, chistory.getCompany_name());
		pst.setString(7, chistory.getEmployement_from());
		pst.setString(8, chistory.getEmployement_to());
		pst.setString(9, chistory.getReason_for_leaving());
		pst.setString(10, chistory.getResponsibilities());
		pst.setString(11, chistory.getHr_rep_name());
		pst.setString(12, chistory.getHr_rep_contact_num());
		
		pst.executeUpdate();
		//logger.info("Registration completed successfully for"+cmaster);
		
	}catch (SQLException e) {
		throw new RecruitmentManagementException("problem in inserting"
				+"work history details"+e.getMessage());
	}
		return chistory.getWork_id();
	}


	@Override
	public boolean updatCandidateWorkHistory() throws RecruitmentManagementException {

		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter work ID");
		String	id = sc.next();
		String sql = "UPDATE candidate_work_history SET candidate_id =?, which_employer=?, contact_person =?, position_held=?, company_name=?, employement_from=?, employement_to=?, reason_for_leaving=?, responsibilities=?, hr_rep_name=?, hr_rep_contact_number=? where work_id=?"; 
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		
		System.out.println("Enter the Details");
		System.out.println("Enter New candidate id");
		String nm = sc.next();
		System.out.println("enter which employer");
		String add = sc.next();
		System.out.println("enter contact person");
		String dob=sc.next();
		System.out.println("enter position held");
		String email=sc.next();
		System.out.println("enter company name");
		String cno=sc.next();
		System.out.println("enter employee from");
		String mstatus=sc.next();
		System.out.println("Enter employement to");
		String gender=sc.next();
		System.out.println("enter reason for leaving");
		String pno=sc.next();
		System.out.println("Enter responsibilities");
		String nm1 = sc.next();
		System.out.println("enter hr rep name");
		String add1 = sc.next();
		System.out.println("enter hr rep contact number");
		String dob1=sc.next();
		
		try {
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, nm);
			pst.setString(2, add);
			pst.setString(3, dob);
			pst.setString(4, email);
			pst.setString(5, cno);
			pst.setString(6, mstatus);
			pst.setString(7, gender);
			pst.setString(8, pno);
			pst.setString(9, nm1);
			pst.setString(10, add1);
			pst.setString(11, dob1);
			pst.setString(12, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new RecruitmentManagementException("problem in updating the details"+e.getMessage());
		}
		return true;	
	
	}
	
	
	}
	
