package com.cg.rms.service;

import com.cg.rms.bean.CandidateWorkHistory;
import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.exception.RecruitmentManagementException;

public interface IRmsService {

	String insertCandidateWorkHistory(CandidateWorkHistory chistory) throws RecruitmentManagementException;
	boolean updateCandidateWorkHistory() throws RecruitmentManagementException;
	
}
