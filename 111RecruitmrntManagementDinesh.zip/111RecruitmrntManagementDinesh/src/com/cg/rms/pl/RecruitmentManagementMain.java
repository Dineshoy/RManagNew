package com.cg.rms.pl;

import java.util.Scanner;

import com.cg.rms.bean.CandidateWorkHistory;
import com.cg.rms.bean.CompanyMaster;
import com.cg.rms.exception.RecruitmentManagementException;
import com.cg.rms.service.IRmsService;
import com.cg.rms.service.IRmsServiceImpl;

public class RecruitmentManagementMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		IRmsService rser = new IRmsServiceImpl();
		

		do {
			System.out.println("Menu");
		
			System.out.println("3. insert candi work hist details");
			System.out.println("4. update candi work hist details");
			
			int choice = sc.nextInt();
			
			switch(choice) {
		
			case 3:	
				try {
					System.out.println("enter candidate id");
					String candidate_id=sc.next();
					System.out.println("enter name of employer");
					String which_employer=sc.next();
					System.out.println("enter contact person");
					String contact_person=sc.next();
					System.out.println("Enter position held");
					String position_held=sc.next();
					System.out.println("enter name of company");
					String company_name=sc.next();
					System.out.println("enter employment from");
					String employement_from=sc.next();
					System.out.println("Enter employment to");
					String employement_to=sc.next();
				    System.out.println("Enter reason for leaving the company");
				    String reason_for_leaving=sc.next();
				    System.out.println("Enter responsibilities");
				    String responsibilities=sc.next();
				    System.out.println("Enter name of HR representative");
				    String hr_rep_name=sc.next();
				    System.out.println("Enter contact number of HR representative");
				    String hr_rep_contact_num=sc.next();
				    
					
					CandidateWorkHistory chistory = new CandidateWorkHistory();
					chistory.setCandidate_id(candidate_id);
					chistory.setWhich_employer(which_employer);
					chistory.setContact_person(contact_person);
					chistory.setPosition_held(position_held);
					chistory.setCompany_name(company_name);
					chistory.setEmployement_from(employement_from);
					chistory.setEmployement_to(employement_to);
					chistory.setReason_for_leaving(reason_for_leaving);
					chistory.setResponsibilities(responsibilities);
					chistory.setHr_rep_name(hr_rep_name);
					chistory.setHr_rep_contact_num(hr_rep_contact_num);


					String comp_id=rser.insertCandidateWorkHistory(chistory);
					System.out.println("Successfully registered with registration id :"+comp_id);
				}catch (RecruitmentManagementException e) {
					System.out.println(e.getMessage());
		
				}
				break;
				
				
			case 4:
				try {
					boolean b = rser.updateCandidateWorkHistory();
					if(b) {
						System.out.println("Details updated s");
					}
				} catch (RecruitmentManagementException e1) {
					e1.printStackTrace();
				}
				
				break;

			}


		}while(true);
	
}}